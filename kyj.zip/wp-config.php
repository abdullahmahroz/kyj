<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kyj');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'w0O8j*xO6 XOW`]%z#C.LR=H<Uu7Fb7|lTF+*edbR=t-NUE~OFd*:sLDI39&/l]#');
define('SECURE_AUTH_KEY',  'MJp5em#jE3] V3I-IN#~rO(OG&74[pM N#A4fu.IG2{WP^*i0,xH+sLT&![@TK7-');
define('LOGGED_IN_KEY',    'J6ASOE*m!a}$3c2S+pwUWid,5DmJZ~In#=YJfXau&Abg5Bx%UN7Vg#bZ=]DA`C/`');
define('NONCE_KEY',        '(2!sUh.m}%?hP8O2Z!2Y2;WP#bKS;b=-AX|mAB_(J]++{`PClDy}22OTC.qh@7cV');
define('AUTH_SALT',        'i&Z/:#NFulhG)c,UZTrR8cx?xHFeN3`]P8=0pYKWdeUfmf+JTA8*3{+Uoh:^AO5[');
define('SECURE_AUTH_SALT', 'PbZXi~;v9:@3*Py=ci?H*gFK~lt.A)+whGb2I~9$K=0M?j~#{Ummwc2foJ#3|Nth');
define('LOGGED_IN_SALT',   'F5$*_{x.E%q?$P]@%#vln]5&q%+rC0A<0w#E]KPW).n?ENt@gY/Qk(U49QN&8ObX');
define('NONCE_SALT',       'i$WWa1_EEM8@m3{bl9|_R(XEr6CP_Z}Tck.EV5-6Ajm7%zLJWMrwg4vpqT!:H#tg');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
